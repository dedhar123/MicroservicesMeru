package com.microservice.price.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.microservice.price.model.Price;

@Repository
public interface PriceDao extends JpaRepository<Price, String>{
	
	   Price findPriceByProductId(String ProductId);

	    void deleteByProductId(String productId);

}
