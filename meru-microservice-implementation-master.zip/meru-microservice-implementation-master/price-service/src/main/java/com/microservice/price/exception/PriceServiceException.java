package com.microservice.price.exception;

public class PriceServiceException extends Exception {

	private static final long serialVersionUID = -6116264869131487893L;

	public PriceServiceException() {
		super();
	}

	public PriceServiceException(final String message) {
		super(message);
	}
}
