package com.microservice.price.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.price.dao.PriceDao;
import com.microservice.price.exception.PriceNotFoundException;
import com.microservice.price.exception.PriceServiceException;
import com.microservice.price.model.Price;

@Service
@Transactional
public class PriceServiceImpl implements PriceService {
	
	@Autowired
	private PriceDao priceDao;
	
	@Override
	public Price getPriceByProduct(String productId) {
		Price prceDeatils= priceDao.findPriceByProductId(productId);
		
		if (null==prceDeatils) {
			throw new PriceNotFoundException("Price not found for product : " + productId);
		}
		return prceDeatils;
	}

	@Override
	public void create(Price price)throws PriceServiceException{
		priceDao.save(price);
	}

	@Override
	public void update(Price price) throws PriceServiceException {
		Price prceDeatils = priceDao.findPriceByProductId(price.getProductId());

		if (null==prceDeatils) {
			throw new PriceNotFoundException("Price not found for product : " + price.getProductId());
		}
		price.setId(prceDeatils.getId());
		
		priceDao.save(price);
		}

	@Override
	public void delete(String productId) {
		priceDao.deleteByProductId(productId);
		
	}

}
