package com.microservice.price.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.price.exception.PriceServiceException;
import com.microservice.price.model.Price;
import com.microservice.price.service.PriceService;

@RestController
@RequestMapping("/price")
public class PriceController {

	@Autowired
	private PriceService priceService;

	@GetMapping("/")
	public Price getPriceByProduct(@RequestParam(value="productId") String productId) {
		return priceService.getPriceByProduct(productId);

	}

	@PostMapping("/create")
	public ResponseEntity<String> create(@RequestBody Price price) throws PriceServiceException {
		priceService.create(price);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@PutMapping("/update")
	public void update(@RequestBody Price price) throws PriceServiceException {
		priceService.update(price);
	}

	@DeleteMapping("/delete/")
	public void delete(@RequestParam("productId") String productId) {
		priceService.delete(productId);
	}

}
