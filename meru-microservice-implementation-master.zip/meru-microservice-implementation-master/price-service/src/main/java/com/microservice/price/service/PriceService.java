package com.microservice.price.service;

import com.microservice.price.exception.PriceServiceException;
import com.microservice.price.model.Price;

public interface PriceService {

	Price getPriceByProduct(String pId) ;

	void create(Price price) throws PriceServiceException;

	void update(Price price) throws PriceServiceException;

	void delete(String pId);

}
