package com.microservice.price.model;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRICE")
public class Price implements Serializable {

	private static final long serialVersionUID = -242577442944124932L;

	@Id
	@Column(name = "PRICE_ID", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name = "ACTUAL_PRICE")
	private String actualPrice;

	@Column(name = "PRODUCT_ID",unique = true)
	private String productId;

	public Price() {

	}

	public String getActualPrice() {
		return actualPrice;
	}

	public void setActualPrice(String actualPrice) {
		this.actualPrice = actualPrice;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Price [id=" + id + ", actualPrice=" + actualPrice
				+ ", productId=" + productId + "]";
	}

}
