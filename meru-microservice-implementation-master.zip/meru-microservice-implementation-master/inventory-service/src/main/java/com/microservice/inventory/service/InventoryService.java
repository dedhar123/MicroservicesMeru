package com.microservice.inventory.service;

import com.microservice.inventory.entity.InventoryItem;
import com.microservice.inventory.exception.InventoryExceptionCheck;

import java.util.List;

public interface InventoryService {
    public List<InventoryItem> retrieveInventoryInfo(String productId) throws InventoryExceptionCheck;

    public boolean addOrUpdateInventoryItem(InventoryItem inventoryItem);

    public  boolean deleteInventoryItem(String productId);
}
