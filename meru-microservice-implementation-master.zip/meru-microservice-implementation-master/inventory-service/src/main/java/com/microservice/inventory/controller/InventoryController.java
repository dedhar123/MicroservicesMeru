package com.microservice.inventory.controller;

import com.microservice.inventory.entity.InventoryItem;
import com.microservice.inventory.exception.InventoryExceptionCheck;
import com.microservice.inventory.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import javax.websocket.server.PathParam;
import java.util.List;

@RestController
@RequestMapping("/inventory")
public class InventoryController {

    @Autowired
    InventoryService inventoryService;

    @GetMapping("/")
    public List<InventoryItem> getInventoryInfoByProductIdAndLocation(@PathParam("productId") @Null String productId) throws InventoryExceptionCheck {
        List<InventoryItem> inventoryItemList = inventoryService.retrieveInventoryInfo(productId);
        return inventoryItemList;
    }

    @PostMapping("/create")
    ResponseEntity<String> addOrUpdateInventoryItem(@RequestBody InventoryItem inventoryItem){
        if(inventoryService.addOrUpdateInventoryItem(inventoryItem))
        	return new ResponseEntity<>(HttpStatus.CREATED);
        else
        	return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @DeleteMapping("/delete")
    boolean deleteInventoryItem(@PathParam("productId") @NotNull String productId){
        return inventoryService.deleteInventoryItem(productId);
    }
}
