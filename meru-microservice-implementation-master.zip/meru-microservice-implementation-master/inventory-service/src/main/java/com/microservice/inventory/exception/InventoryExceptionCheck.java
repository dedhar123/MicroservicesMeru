package com.microservice.inventory.exception;

public class InventoryExceptionCheck extends Exception {

    public InventoryExceptionCheck(String message) {
        super(message);
    }
}
