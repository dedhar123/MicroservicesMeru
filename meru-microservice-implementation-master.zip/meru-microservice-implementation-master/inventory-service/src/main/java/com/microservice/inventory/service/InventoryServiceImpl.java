package com.microservice.inventory.service;

import com.microservice.inventory.dao.InventoryDao;
import com.microservice.inventory.entity.InventoryItem;
import com.microservice.inventory.exception.InventoryExceptionCheck;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Component
@Transactional
@Service
public class InventoryServiceImpl implements InventoryService{

    @Autowired
    InventoryDao inventoryDao;

    public List<InventoryItem> retrieveInventoryInfo(String productId) throws InventoryExceptionCheck {
        List<InventoryItem> inventoryItemList = new ArrayList<>();
        System.out.println("Product ID: " + productId);
        try {
            if ((null != productId) && !(("").equals(productId.trim()))) {
                InventoryItem inventoryItem = inventoryDao.findInventoryByProductId(productId);

                if(null != inventoryItem)
                    inventoryItemList.add(inventoryItem);
            } else {
                inventoryItemList = (List<InventoryItem>) inventoryDao.findAll();
            }
        } catch (Exception e){
            e.printStackTrace();
        }

        if( null== inventoryItemList || inventoryItemList.size() == 0){
            throw new InventoryExceptionCheck("No Inventory found for the product id : " + productId);
        }
        return inventoryItemList;
    }

    @Override
    public boolean addOrUpdateInventoryItem(InventoryItem inventoryItem) {
        //--
        /*InstanceInfo instanceInfo = productViewClient.getNextServerFromEureka("zuulapigateway", false);
        String baseUrl = instanceInfo.getHomePageUrl();
        baseUrl+="/api/product-service/product/?productId="+inventoryItem.getProductId();
        String response =  restTemplate.getForObject(baseUrl, String.class);
        response = response.replaceAll("\\[", "").replaceAll("\\]","");
        //JsonObject jsonResponse = new JsonParser().parse(response).getAsJsonObject();
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(stringToParse);*/
        //--
        boolean status = true;
        InventoryItem itemCreated = inventoryDao.findInventoryByProductId(inventoryItem.getProductId());
        if(null != itemCreated){
            inventoryItem.setInventoryItemId(itemCreated.getInventoryItemId());
        }
        try{
            inventoryDao.save(inventoryItem);
        } catch(Exception e){
            status = false;
            e.printStackTrace();
        }
        return status;
    }

    @Override
    public boolean deleteInventoryItem(String productId) {
        boolean status = true;
        try {
            inventoryDao.deleteByProductId(productId);
        } catch(Exception e){
            status = false;
            e.printStackTrace();
        }
        return status;
    }


}
