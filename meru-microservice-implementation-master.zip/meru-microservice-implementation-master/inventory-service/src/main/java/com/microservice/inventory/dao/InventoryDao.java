package com.microservice.inventory.dao;

import com.microservice.inventory.entity.InventoryItem;
import org.springframework.data.repository.CrudRepository;

public interface InventoryDao extends CrudRepository<InventoryItem, String> {

    InventoryItem findInventoryByProductId(String ProductId);

    void deleteByProductId(String productId);
}
