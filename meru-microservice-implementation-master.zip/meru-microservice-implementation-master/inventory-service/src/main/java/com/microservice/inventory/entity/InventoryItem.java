package com.microservice.inventory.entity;

import jdk.nashorn.internal.objects.annotations.Getter;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "INVNTRY_ITM")
public class InventoryItem implements Serializable {

    @Id
    @Column(name= "INVNTRY_ITM_ID", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long inventoryItemId;

    @Column(name = "PRDCT_ID", nullable = false)
    private String productId;

    @Column(name = "QNTY")
    private int stock;

    @Column(name = "LOCTN")
    private String location;

    public InventoryItem()
    {
    	
    }
    public InventoryItem(long inventoryItemId, String productId, int stock, String location) {
        this.inventoryItemId = inventoryItemId;
        this.productId = productId;
        this.stock = stock;
        this.location = location;
    }

    public long getInventoryItemId() {
        return inventoryItemId;
    }

    public void setInventoryItemId(long inventoryItemId) {
        this.inventoryItemId = inventoryItemId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override
    public String toString() {
        return "InventoryItem{" +
                "inventoryItemId=" + inventoryItemId +
                ", productId='" + productId + '\'' +
                ", stock=" + stock +
                ", location=" + location +
                '}';
    }
}
