package com.microservice.inventory.controller;

import com.google.gson.Gson;
import com.microservice.inventory.InventoryServiceApplication;
import com.microservice.inventory.entity.InventoryItem;
import com.microservice.inventory.service.InventoryServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(InventoryController.class)
@ContextConfiguration(classes= InventoryServiceApplication.class)
public class InventoryControllerTest {

    String productId = "P002";

    @MockBean
    InventoryServiceImpl inventoryService;

    @Autowired
    private MockMvc mvc;

    @Test
    public void testGetAllInventorys() throws Exception {
        List<InventoryItem> inventoryItemList = createInventorys();
        InventoryItem itemToCheck = new InventoryItem(123457 , "P002", 50, "Kolkata");
        given(inventoryService.retrieveInventoryInfo(null)).willReturn(inventoryItemList);

        mvc.perform(
                get("/inventory/")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$" , hasSize(2)))
                ;
    }

    @Test
    public void testGetInventoryByProductId() throws Exception {
        List<InventoryItem> inventoryItemList = createInventorys();
        InventoryItem itemToCheck = new InventoryItem(123457 , "P002", 50, "Kolkata");
        given(inventoryService.retrieveInventoryInfo(productId)).willReturn(inventoryItemList);

        mvc.perform(
                get("/inventory/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .param("productId", productId))
                .andExpect(status().isOk())
                .andExpect( jsonPath("$" , hasSize(2)))
                .andExpect( jsonPath("$[0].productId" , is(itemToCheck.getProductId())))
        ;
    }

    @Test
    public void testPostInventoryByProductId() throws Exception {
        InventoryItem itemToCheck = new InventoryItem(123457 , "P002", 50, "Kolkata");

        Gson gson = new Gson();
        String json = gson.toJson(itemToCheck);
        given(inventoryService.addOrUpdateInventoryItem(any(InventoryItem.class))).willReturn(true);

        mvc.perform(
                post("/inventory/create")
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(json)
        )
                .andDo(print())
                .andExpect(status().isCreated())
        ;

        //Exception check
        given(inventoryService.addOrUpdateInventoryItem(any(InventoryItem.class))).willReturn(false);
        mvc.perform(
                post("/inventory/create")
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(json)
        )
                .andDo(print())
                .andExpect(status().isInternalServerError())
        ;
    }

    @Test
    public void testDeleteInventorys() throws Exception {
        boolean deleteStatus = true;
        given(inventoryService.deleteInventoryItem(productId)).willReturn(true);

        mvc.perform(
                delete("/inventory/delete")
                        .contentType(MediaType.APPLICATION_JSON)
                        .param("productId", productId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$" , is(deleteStatus)))
        ;
    }
    private List<InventoryItem> createInventorys() {
        List<InventoryItem> items = new ArrayList<>();
        InventoryItem item1 = new InventoryItem(123456 , "P002", 50, "Kolkata");
        InventoryItem item2 = new InventoryItem(123457 , "P001", 50, "Kolkata");

        items.add(item1);
        items.add(item2);
        return items;
    }
}
