package com.microservice.inventory.service;

import com.microservice.inventory.dao.InventoryDao;
import com.microservice.inventory.entity.InventoryItem;
import com.microservice.inventory.exception.InventoryExceptionCheck;
import com.microservice.inventory.service.InventoryService;
import com.microservice.inventory.service.InventoryServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
public class InventoryServiceTest {

    @TestConfiguration
    static class InventoryServiceImplTestContextConfig {
        @Bean
        public InventoryService inventoryService(){
            return new InventoryServiceImpl();
        }
    }

    @MockBean
    InventoryDao inventoryDao;

    @Autowired
    InventoryService inventoryService;

    String productId;

    @Before
    public void setUp(){
        productId = "P001";
    }

    @Test
    public void testRetrieveInventorys() throws InventoryExceptionCheck {
        List<InventoryItem> inventoryItemList = createInventorys();
        InventoryItem itemToCheck = new InventoryItem(123456 , "P001", 50, "Kolkata");
        given(inventoryDao.findInventoryByProductId(productId)).willReturn(itemToCheck);
        given(inventoryDao.findAll()).willReturn(inventoryItemList);

        List<InventoryItem> inventoryItems = inventoryService.retrieveInventoryInfo(productId);

        assertNotNull(inventoryItems);
        assertEquals(1, inventoryItems.size());
        assertEquals(productId , inventoryItemList.get(0).getProductId());

        List<InventoryItem> allInventoryItems = inventoryService.retrieveInventoryInfo(null);

        assertNotNull(allInventoryItems);
        assertEquals(2, allInventoryItems.size());
    }

    @Test
    public void testDelete() {
        boolean deleteStatus;
        //Exception scenario
        doThrow(NullPointerException.class).when(inventoryDao).deleteByProductId(productId);
        deleteStatus = inventoryService.deleteInventoryItem(productId);
        assertEquals(false, deleteStatus);

        //success scenario
        doNothing().when(inventoryDao).deleteByProductId(productId);
        deleteStatus = inventoryService.deleteInventoryItem(productId);
        assertEquals(true, deleteStatus);
    }

    @Test
    public void testCreateOrUpdate(){
        boolean status = false;
        InventoryItem itemToCheck = new InventoryItem(123456 , "P001", 50, "Kolkata");

        when(inventoryDao.findInventoryByProductId(productId)).thenReturn(itemToCheck);
        when(inventoryDao.save(itemToCheck)).thenReturn(null);
        status = inventoryService.addOrUpdateInventoryItem(itemToCheck);
        assertEquals(true, status);

        doThrow(NullPointerException.class).when(inventoryDao).save(itemToCheck);
        status = inventoryService.addOrUpdateInventoryItem(itemToCheck);
        assertEquals(false, status);
    }

    private List<InventoryItem> createInventorys() {
        List<InventoryItem> items = new ArrayList<>();
        InventoryItem item1 = new InventoryItem(123456 , "P001", 50, "Kolkata");;
        InventoryItem item2 = new InventoryItem(123457 , "P002", 50, "Kolkata");

        items.add(item1);
        items.add(item2);
        return items;
    }
}
