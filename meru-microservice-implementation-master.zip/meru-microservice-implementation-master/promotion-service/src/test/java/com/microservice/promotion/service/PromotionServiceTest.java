package com.microservice.promotion.service;

import com.microservice.promotion.PromotionServiceApplication;
import com.microservice.promotion.dao.PromotionDao;
import com.microservice.promotion.entity.PromotionItem;
import com.microservice.promotion.exception.PromotionExceptionCheck;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willThrow;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
public class PromotionServiceTest {

    @TestConfiguration
    static class PromotionServiceImplTestContextConfig {
        @Bean
        public PromotionService promotionService(){
            return new PromotionServiceImpl();
        }
    }

    @MockBean
    PromotionDao promotionDao;

    @Autowired
    PromotionService promotionService;

    String productId;

    @Before
    public void setUp(){
        productId = "P001";
    }

    @Test
    public void testRetrievePromotions() throws PromotionExceptionCheck {
        List<PromotionItem> promotionItemList = createPromotions();
        PromotionItem itemToCheck = new PromotionItem(123456 , "P001", 50, new Date(),new Date());
        given(promotionDao.findPromotionByProductId(productId)).willReturn(itemToCheck);
        given(promotionDao.findAll()).willReturn(promotionItemList);

        List<PromotionItem> promotionItems = promotionService.retrievePromotionInfo(productId);

        assertNotNull(promotionItems);
        assertEquals(1, promotionItems.size());
        assertEquals(productId , promotionItemList.get(0).getProductId());

        List<PromotionItem> allPromotionItems = promotionService.retrievePromotionInfo(null);

        assertNotNull(allPromotionItems);
        assertEquals(2, allPromotionItems.size());
    }

    @Test
    public void testDelete() {
        boolean deleteStatus;
        //Exception scenario
        doThrow(NullPointerException.class).when(promotionDao).deleteByProductId(productId);
        deleteStatus = promotionService.deletePromotionByProductId(productId);
        assertEquals(false, deleteStatus);

        //success scenario
        doNothing().when(promotionDao).deleteByProductId(productId);
        deleteStatus = promotionService.deletePromotionByProductId(productId);
        assertEquals(true, deleteStatus);
    }

    @Test
    public void testCreateOrUpdate(){
        boolean status = false;
        PromotionItem itemToCheck = new PromotionItem(123456 , productId, 50, new Date(),new Date());

        when(promotionDao.findPromotionByProductId(productId)).thenReturn(itemToCheck);
        when(promotionDao.save(itemToCheck)).thenReturn(null);
        status = promotionService.createOrUpdateNewPromotion(itemToCheck);
        assertEquals(true, status);

        doThrow(NullPointerException.class).when(promotionDao).save(itemToCheck);
        status = promotionService.createOrUpdateNewPromotion(itemToCheck);
        assertEquals(false, status);
    }

    private List<PromotionItem> createPromotions() {
        List<PromotionItem> items = new ArrayList<>();
        PromotionItem item1 = new PromotionItem(123456, "P001", 50, new Date(),new Date());
        PromotionItem item2 = new PromotionItem(123457, "P002", 30, new Date(),new Date());

        items.add(item1);
        items.add(item2);
        return items;
    }
}
