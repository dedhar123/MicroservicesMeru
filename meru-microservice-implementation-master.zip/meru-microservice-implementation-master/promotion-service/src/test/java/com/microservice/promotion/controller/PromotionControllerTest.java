package com.microservice.promotion.controller;

import com.google.gson.Gson;
import com.microservice.promotion.PromotionServiceApplication;
import com.microservice.promotion.entity.PromotionItem;
import com.microservice.promotion.service.PromotionServiceImpl;
import net.minidev.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(PromotionController.class)
@ContextConfiguration(classes= PromotionServiceApplication.class)
public class PromotionControllerTest {

    String productId = "P001";

    @MockBean
    PromotionServiceImpl promotionService;

    @Autowired
    private MockMvc mvc;

    @Test
    public void testGetAllPromotions() throws Exception {
        List<PromotionItem> promotionItemList = createPromotions();
        PromotionItem itemToCheck = new PromotionItem(123456, productId, 50, new Date(),new Date());
        given(promotionService.retrievePromotionInfo(null)).willReturn(promotionItemList);

        mvc.perform(
                get("/promotion/")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$" , hasSize(2)))
                ;
    }

    @Test
    public void testGetPromotionByProductId() throws Exception {
        List<PromotionItem> promotionItemList = createPromotions();
        PromotionItem itemToCheck = new PromotionItem(123456, productId, 50, new Date(),new Date());
        given(promotionService.retrievePromotionInfo(productId)).willReturn(promotionItemList);

        mvc.perform(
                get("/promotion/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .param("productId", productId))
                .andExpect(status().isOk())
                .andExpect( jsonPath("$" , hasSize(2)))
                .andExpect( jsonPath("$[0].productId" , is(itemToCheck.getProductId())))
        ;
    }

    @Test
    public void testPostPromotionByProductId() throws Exception {
        PromotionItem itemToCheck = new PromotionItem(123456, productId, 50, null , null);

        Gson gson = new Gson();
        String json = gson.toJson(itemToCheck);
        given(promotionService.createOrUpdateNewPromotion(any(PromotionItem.class))).willReturn(true);

        mvc.perform(
                post("/promotion/create")
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(json)
        )
                .andDo(print())
                .andExpect(status().isCreated())
        ;

        //Exception check
        given(promotionService.createOrUpdateNewPromotion(any(PromotionItem.class))).willReturn(false);
        mvc.perform(
                post("/promotion/create")
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(json)
        )
                .andDo(print())
                .andExpect(status().isInternalServerError())
        ;
    }

    @Test
    public void testDeletePromotions() throws Exception {
        boolean deleteStatus = true;
        given(promotionService.deletePromotionByProductId(productId)).willReturn(true);

        mvc.perform(
                delete("/promotion/delete")
                        .contentType(MediaType.APPLICATION_JSON)
                        .param("productId", productId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$" , is(deleteStatus)))
        ;
    }
    private List<PromotionItem> createPromotions() {
        List<PromotionItem> items = new ArrayList<>();
        PromotionItem item1 = new PromotionItem(123456, productId, 50, new Date(),new Date());
        PromotionItem item2 = new PromotionItem(123457, "P002", 50, new Date(),new Date());

        items.add(item1);
        items.add(item2);
        return items;
    }
}
