package com.microservice.promotion.service;

import com.microservice.promotion.entity.PromotionItem;
import com.microservice.promotion.exception.PromotionExceptionCheck;

import java.util.List;

public interface PromotionService {

    public List<PromotionItem> retrievePromotionInfo(String productId) throws PromotionExceptionCheck;
    public boolean deletePromotionByProductId(String productId);
    public boolean createOrUpdateNewPromotion(PromotionItem promotionItem);
}
