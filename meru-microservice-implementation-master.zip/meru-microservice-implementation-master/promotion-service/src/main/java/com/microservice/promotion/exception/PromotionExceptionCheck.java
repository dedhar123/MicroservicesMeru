package com.microservice.promotion.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

public class PromotionExceptionCheck extends Exception {

    public PromotionExceptionCheck(String message) {
        super(message);
    }
}
