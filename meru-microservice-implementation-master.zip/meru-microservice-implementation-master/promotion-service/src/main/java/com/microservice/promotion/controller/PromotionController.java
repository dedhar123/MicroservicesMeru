package com.microservice.promotion.controller;

import com.microservice.promotion.entity.PromotionItem;
import com.microservice.promotion.exception.PromotionExceptionCheck;
import com.microservice.promotion.service.PromotionServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.websocket.server.PathParam;
import java.util.List;

@RequestMapping("/promotion")
@RestController
class PromotionController{

    @Autowired
    PromotionServiceImpl promotionService;


    @GetMapping("/")
    public List<PromotionItem> getProducInfoByProductId(@PathParam("productId") String productId) throws PromotionExceptionCheck {
        List<PromotionItem> promotionItemList = promotionService.retrievePromotionInfo(productId);
        return promotionItemList;
    }

    @DeleteMapping("/delete")
    public boolean deletePromotionInfoById(@PathParam("productId") String productId) {
        boolean deleteStatus;
        deleteStatus = promotionService.deletePromotionByProductId(productId);
        return deleteStatus;
    }

    @PostMapping("/create")
    public ResponseEntity<String> addProductInfo(@RequestBody PromotionItem promotionItem) {
    	if(promotionService.createOrUpdateNewPromotion(promotionItem))
        	return new ResponseEntity<>(HttpStatus.CREATED);
        else
        	return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }
}