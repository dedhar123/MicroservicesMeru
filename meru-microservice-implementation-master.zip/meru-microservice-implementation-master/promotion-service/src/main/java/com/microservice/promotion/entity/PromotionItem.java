package com.microservice.promotion.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "PRMTN_ITM")
public class PromotionItem implements Serializable {

    @Id
    @Column(name="PRMTN_ITM_ID", nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long promotionId;

    @Column(name="PRD_ID", nullable = false)
    private String productId;

    @Column(name="DSCNT_PRCNTG")
    private int discountPercentage;

    @Column(name="PRMTN_STRT_DT")
    private Date promotionStartDate;

    @Column(name="PRMTN_END_DT")
    private Date promotionEndDate;

    public PromotionItem()
    {
    	
    }
    public PromotionItem(long promotionId, String productId, int discountPercentage, Date promotionStartDate, Date promotionEndDate) {
        this.promotionId = promotionId;
        this.productId = productId;
        this.discountPercentage = discountPercentage;
        this.promotionStartDate = promotionStartDate;
        this.promotionEndDate = promotionEndDate;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public long getPromotionId() {
        return promotionId;
    }

    public void setPromotionId(long promotionId) {
        this.promotionId = promotionId;
    }

    public int getDiscountPercentage() {
        return discountPercentage;
    }

    public void setDiscountPercentage(int discountPercentage) {
        this.discountPercentage = discountPercentage;
    }

    public Date getPromotionStartDate() {
        return promotionStartDate;
    }

    public void setPromotionStartDate(Date promotionStartDate) {
        this.promotionStartDate = promotionStartDate;
    }

    public Date getPromotionEndDate() {
        return promotionEndDate;
    }

    public void setPromotionEndDate(Date promotionEndDate) {
        this.promotionEndDate = promotionEndDate;
    }

    @Override
    public String toString() {
        return "PromotionItem{" +
                "promotionId=" + promotionId +
                ", productId=" + productId +
                ", discountPercentage=" + discountPercentage +
                ", promotionStartDate=" + promotionStartDate +
                ", promotionEndDate=" + promotionEndDate +
                '}';
    }
}
