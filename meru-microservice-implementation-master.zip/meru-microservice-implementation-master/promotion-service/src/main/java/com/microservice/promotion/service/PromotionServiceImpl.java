package com.microservice.promotion.service;

import com.microservice.promotion.dao.PromotionDao;
import com.microservice.promotion.entity.PromotionItem;
import com.microservice.promotion.exception.PromotionExceptionCheck;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Transactional
@Service
public class PromotionServiceImpl implements PromotionService {

    @Autowired
    PromotionDao promotionDao;

    public List<PromotionItem> retrievePromotionInfo(String productId) throws PromotionExceptionCheck {
        List<PromotionItem> promotionItemList = new ArrayList<>();
        System.out.println("productId : " + productId);
        try {
            if ((null != productId) && !(("").equals(productId.trim()))) {
                PromotionItem promotionItem = promotionDao.findPromotionByProductId(productId);

                if(null != promotionItem)
                    promotionItemList.add(promotionItem);
            } else {
                promotionItemList = (List<PromotionItem>) promotionDao.findAll();
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        if( null== promotionItemList || promotionItemList.size() == 0){
            throw new PromotionExceptionCheck("No Promotion found for the product id : " + productId);
        }
        return promotionItemList;
    }

    public boolean deletePromotionByProductId(String productId) {
        boolean status = true;
        try {
            promotionDao.deleteByProductId(productId);
        } catch(NullPointerException e){
            status = false;
            e.printStackTrace();
        }
        return status;
    }

    public boolean createOrUpdateNewPromotion(PromotionItem promotionItem) {
        boolean status = true;

        try{
            PromotionItem itemCreated = promotionDao.findPromotionByProductId(promotionItem.getProductId());
            if(null != itemCreated){
                promotionItem.setPromotionId(itemCreated.getPromotionId());
            }
            promotionDao.save(promotionItem);
        } catch(NullPointerException e){
            status = false;
            e.printStackTrace();
        }
        return status;
    }
}
