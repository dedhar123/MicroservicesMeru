package com.microservice.promotion.dao;

import com.microservice.promotion.entity.PromotionItem;
import org.springframework.data.repository.CrudRepository;

public interface PromotionDao extends CrudRepository<PromotionItem, String> {

    PromotionItem findPromotionByProductId(String productId);
    void deleteByProductId(String productId);
}
