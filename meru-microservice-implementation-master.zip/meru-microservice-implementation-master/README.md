Prerequisites: Eclipse IDE, MySQL Server 5.7
- Clone the repository
- After cloning, you will get meru-microservice-implementation as a local repo in your system
- Inside this repo, run the meru-docker-run.sh script if you want to run everything in dockerized environment(Before this make sure you have docker installed,have openjdk:8 and mysql:5.7 images installed inside docker runtime and the target folders in your services have their respective jars generated. You can use mvn package for that)
- If you don't want to run this in dockerized environment, simply import the whole project into eclipse and run individual services.