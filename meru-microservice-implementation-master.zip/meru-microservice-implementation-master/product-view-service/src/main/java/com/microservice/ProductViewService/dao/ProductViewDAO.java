package com.microservice.ProductViewService.dao;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.microservice.ProductViewService.model.*;
@Repository
public interface ProductViewDAO extends CrudRepository<ProductView,String> {
	ProductView findByProductId(String productId);
	void deleteByProductId(String productId);
}
