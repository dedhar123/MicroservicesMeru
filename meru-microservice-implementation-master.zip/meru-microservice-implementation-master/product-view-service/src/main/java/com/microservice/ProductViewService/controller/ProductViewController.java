package com.microservice.ProductViewService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.ProductViewService.exception.ProductViewNotFoundException;
import com.microservice.ProductViewService.model.ProductView;
import com.microservice.ProductViewService.service.ProductViewService;

@RestController
@RequestMapping("/productView")
public class ProductViewController {
@Autowired
private ProductViewService productViewService;	
@RequestMapping(value = "/create",method = RequestMethod.POST)
public ResponseEntity<String> createProductView(@RequestBody ProductView productView)
{
	if(productViewService.createProductView(productView.getProductId()))
    	return new ResponseEntity<>(HttpStatus.CREATED);
    else
    	return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	
}
@RequestMapping(value = "/update",method = RequestMethod.PUT)
public String updateProductView(@RequestParam("productId") String productId)
{
	boolean status = productViewService.updateProductView(productId);
	return (status==true)?"ProductView Updated":"ProductView can't be fetched";
}
@RequestMapping(value= "/delete/",method = RequestMethod.DELETE)
public String deleteProductView(@RequestParam("productId") String productId)
{
	productViewService.deleteProductView(productId);
	return "ProductView Deleted";
}
@RequestMapping("/")
public ProductView displayProductView(@RequestParam("productId") String productId)
{
	return productViewService.displayProductView(productId);
}
@RequestMapping("/all")
public List<ProductView> displayAllProductsView() throws ProductViewNotFoundException
{
	return productViewService.displayAllProductsView();
}
}
