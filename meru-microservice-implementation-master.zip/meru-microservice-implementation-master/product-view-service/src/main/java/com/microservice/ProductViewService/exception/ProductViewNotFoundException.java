package com.microservice.ProductViewService.exception;

public class ProductViewNotFoundException extends Exception {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public ProductViewNotFoundException(String message)
{
	super(message);
}
}
