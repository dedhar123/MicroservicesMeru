package com.microservice.ProductViewService.service;

import java.util.List;

import org.springframework.web.client.RestTemplate;

import com.google.gson.JsonObject;
import com.microservice.ProductViewService.exception.ProductViewNotFoundException;
import com.microservice.ProductViewService.model.ProductView;
import com.netflix.discovery.EurekaClient;

public interface ProductViewService {
	public boolean createProductView(String productId);
	public boolean updateProductView(String productId);
	public void deleteProductView(String productId);
	public ProductView displayProductView(String productId);
	public List<ProductView> displayAllProductsView() throws ProductViewNotFoundException;
	public JsonObject getService(String serviceName,RestTemplate restTemplate,EurekaClient productViewClient,String productId);
	public String applyPromotion(String price,String promotion);
	public String applyStockView(String stock);
}