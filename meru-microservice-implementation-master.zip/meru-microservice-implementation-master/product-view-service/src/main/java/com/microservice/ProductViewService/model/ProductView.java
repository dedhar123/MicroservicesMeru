package com.microservice.ProductViewService.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ProductView {
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	@Column(unique=true)
	private String productId;
	private String name;
	private String description;
	private String retailprice;
	private String dealprice;
	private String discount;
	private String stock;
	public ProductView()
	{
		
	}
	public ProductView(String productId, String name, String description, String retailprice, String dealprice, String stock)
	{
		this.productId=productId;
		this.name = name;
		this.description=description;
		this.retailprice=retailprice;
		this.dealprice=dealprice;
		this.stock=stock;
	}
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id=id;
	}
	public String getProductId()
	{
		return productId;
	}
	public void setProductId(String productId)
	{
		this.productId=productId;
	}
	public String getName()
	{
		return name;
	}
	public void  setName(String name)
	{
		this.name=name;
	}
	public String getDescription()
	{
		return description;
	}
	public void  setDescription(String description)
	{
		this.description=description;
	}
	public String getRetailPrice()
	{
		return retailprice;
	}
	public void  setRetailPrice (String retailprice)
	{
		this.retailprice=retailprice;
	}
	public String getDealPrice()
	{
		return dealprice;
	}
	public void  setDealPrice(String dealprice)
	{
		this.dealprice=dealprice;
	}
	public String getDiscount()
	{
		return discount;
	}
	public void setDiscount(String discount)
	{
		this.discount=discount;
	}
	public String getStock ()
	{
		return stock;
	}
	public void setStock (String stock)
	{
		this.stock=stock;
	}

}
