package com.microservice.ProductViewService.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.microservice.ProductViewService.dao.ProductViewDAO;
import com.microservice.ProductViewService.exception.ProductViewNotFoundException;
import com.microservice.ProductViewService.model.ProductView;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
@Transactional
public class ProductViewServiceImpl implements ProductViewService {
	@Autowired
	private ProductViewDAO productViewDAO;
	@Autowired
	private EurekaClient productViewClient;
	@Autowired
	private RestTemplateBuilder restTemplateBuilder;
	
	public boolean createProductView(String productId)
	{
		boolean status = true;
		ProductView pV = new ProductView();
		pV.setProductId(productId);
		try
		{
		productViewDAO.save(pV);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			status=false;
		}
		return status;
	}
	@HystrixCommand(fallbackMethod="updateProductViewFallBack")
	public boolean updateProductView(String productId)
	{
		boolean status = false;
		RestTemplate restTemplate = restTemplateBuilder.build();
		ProductView pV = productViewDAO.findByProductId(productId);
		if(pV!=null)
		{
		//Fetching response
		JsonObject productResponse = getService("product-service/product/",restTemplate,productViewClient,productId);
		JsonObject priceResponse = getService("price-service/price/",restTemplate,productViewClient,productId);
		JsonObject promotionResponse = getService("promotion-service/promotion/",restTemplate,productViewClient,productId);
		JsonObject inventoryResponse=getService("inventory-service/inventory/",restTemplate,productViewClient,productId);
		//Setting ProductView Entity
		pV.setName(productResponse.get("name").getAsString());
		pV.setDescription(productResponse.get("description").getAsString());
		pV.setRetailPrice (priceResponse.get("actualPrice").getAsString());
		pV.setDealPrice(applyPromotion(priceResponse.get("actualPrice").getAsString(),promotionResponse.get("discountPercentage").getAsString()));
		pV.setStock (applyStockView(inventoryResponse.get("stock").getAsString()));
		pV.setDiscount(promotionResponse.get("discountPercentage").getAsString()+"%");
		
		//pV.setName("Google Pixel 2");
		//pV.setDescription("Best camera smartphone out there");
		//pV.setRetailPrice("50000");
		//pV.setDealPrice(applyPromotion("50000","25"));
		//pV.setStock(applyStockView("2"));
		
		//saving Entity
		productViewDAO.save(pV);
		status=true;
		}
		return status;

	}
	public boolean updateProductViewFallBack(String productId)
	{
		return false;
	}
	public void deleteProductView(String productId)
	{
		productViewDAO.deleteByProductId(productId);
		
	}
	public ProductView displayProductView(String productId)
	{
		return productViewDAO.findByProductId (productId);
	}
	public List<ProductView> displayAllProductsView() throws ProductViewNotFoundException
	{
	List<ProductView> productViews =(List<ProductView>) productViewDAO.findAll();
	if(productViews.isEmpty())
		throw new ProductViewNotFoundException("There are no product views available");
	return productViews;
	}
	//Get service call
	public JsonObject getService(String serviceName,RestTemplate restTemplate,EurekaClient productViewClient,String productId)
	{
		/*Using Eureka Server
		InstanceInfo instanceInfo = productViewClient.getNextServerFromEureka(serviceName, false);
		String baseUrl = instanceInfo.getHomePageUrl();
		baseUrl+="?productId="+productId;
		String response =  restTemplate.getForObject(baseUrl,String.class );
		JsonObject jsonResponse = new JsonParser().parse(response).getAsJsonObject();
		return jsonResponse;
		*/
		//Using Zuul Gateway
		InstanceInfo instanceInfo = productViewClient.getNextServerFromEureka("zuulapigateway", false);
		String baseUrl = instanceInfo.getHomePageUrl();
		baseUrl+="/api/"+serviceName+"?productId="+productId;
		String response =  restTemplate.getForObject(baseUrl,String.class );
		response = response.replaceAll("\\[", "").replaceAll("\\]","");
		JsonObject jsonResponse = new JsonParser().parse(response).getAsJsonObject();
		return jsonResponse;
		
		
	}
	//Promotion Logic
	public String applyPromotion(String price,String promotion)
	{
		int Price = Integer.parseInt(price);
		int Promotion = Integer.parseInt(promotion);
		int DealPrice = Price-((Price*Promotion)/100);
		return String.valueOf(DealPrice);
	}
	//Stock View Logic
	public String applyStockView(String stock)
	{
		int Stock = Integer.parseInt(stock);
		if(Stock==0)
		return "Out of Stock";
		else if(Stock>2)
		return  stock+" items available";
		else
		return "Only "+Stock+" left in stock";	
	}
	
}
