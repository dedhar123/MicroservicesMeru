package com.microservice.ProductViewService.dao;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import com.microservice.ProductViewService.model.ProductView;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@DataJpaTest
public class ProductViewDAOTest {

	@Autowired
	private TestEntityManager entityManager;
	
	@Autowired
	private ProductViewDAO productViewDAO;
	
	@Test
	public void testFindByProductId() {
		ProductView pV = new ProductView("gpxl2","Google Pixel 2","Best camera smartphone in the world","50000","37500","3");
		entityManager.persist(pV);
		entityManager.flush();
		ProductView pVfound = productViewDAO.findByProductId("gpxl2");
		assertEquals("gpxl2",pVfound.getProductId());
	}

	@Test
	public void testDeleteByProductId() {
		ProductView pV = new ProductView("gpxl2","Google Pixel 2","Best camera smartphone in the world","50000","37500","3");
		entityManager.persist(pV);
		ProductView pV2 = new ProductView("ipx","Google Pixel 2","Best camera smartphone in the world","50000","37500","3");
		entityManager.persist(pV2);
		entityManager.flush();
		productViewDAO.deleteByProductId("gpxl2");
		assertNull(productViewDAO.findByProductId("gpxl12"));
		assertNotNull(productViewDAO.findByProductId("ipx"));
		
	}

}
