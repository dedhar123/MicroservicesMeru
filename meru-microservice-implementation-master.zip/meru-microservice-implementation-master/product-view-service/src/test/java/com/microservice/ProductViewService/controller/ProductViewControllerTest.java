package com.microservice.ProductViewService.controller;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import javax.ws.rs.core.MediaType;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import static org.mockito.Mockito.*;

import com.google.gson.Gson;
import com.microservice.ProductViewService.model.ProductView;
import com.microservice.ProductViewService.service.ProductViewService;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.*;
import static org.hamcrest.Matchers.*;

@WebMvcTest
@RunWith(SpringRunner.class)
public class ProductViewControllerTest {
	@Autowired
	private MockMvc mvc;
	@MockBean
	private ProductViewService productViewService;
	@Test
	public void testCreateProductView() throws Exception {
	    ProductView pV = new ProductView("gpxl2",null,null,null,null,null);
	    Mockito.when(productViewService.createProductView("gpxl2")).thenReturn(true);
        mvc.perform(
                post("/productView/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new Gson().toJson(pV)))
                .andExpect(status().isCreated());
        verify(productViewService,times(1)).createProductView("gpxl2");

	}

	@Test
	public void testUpdateProductView() throws Exception {
		ProductView pV = new ProductView("gpxl2",null,null,null,null,null);
	    when(productViewService.updateProductView("gpxl2")).thenReturn(true);

        mvc.perform(
                put("/productView/update?productId=gpxl2")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new Gson().toJson(pV)))
                .andExpect(status().isOk());
        verify(productViewService,times(1)).updateProductView("gpxl2");
	}

	@Test
	public void testDeleteProductView() throws Exception {
		doNothing().when(productViewService).deleteProductView("gpxl2");
        mvc.perform(
                delete("/productView/delete/?productId=gpxl2"))
                .andExpect(status().isOk());
        verify(productViewService,times(1)).deleteProductView("gpxl2");
	}

	@Test
	public void testDisplayProductView() throws Exception {
		ProductView pV = new ProductView("gpxl2","Google Pixel 2","Best camera smartphone in the world","50000","37500","3");
		Mockito.when(productViewService.displayProductView("gpxl2")).thenReturn(pV);
		mvc.perform(
				get("/productView/?productId=gpxl2")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.name",is(pV.getName())))
				.andExpect(jsonPath("$.description",is(pV.getDescription())));
	}

	@Test
	public void testDisplayAllProductsView() throws Exception {
		ProductView pV = new ProductView("gpxl2","Google Pixel 2","Best camera smartphone in the world","50000","37500","3");
		ProductView pV2 = new ProductView("ipx","Google Pixel 2","Best camera smartphone in the world","50000","37500","3");
		List<ProductView> pVS = Arrays.asList(pV,pV2);
		Mockito.when(productViewService.displayAllProductsView()).thenReturn(pVS);
		mvc.perform(
				get("/productView/all")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$",hasSize(2)))
				.andExpect(jsonPath("$[0].name",is(pV.getName())))
				.andExpect(jsonPath("$[0].description",is(pV.getDescription())))
				.andExpect(jsonPath("$[1].name",is(pV2.getName())))
				.andExpect(jsonPath("$[1].description",is(pV2.getDescription())));
	}

}
