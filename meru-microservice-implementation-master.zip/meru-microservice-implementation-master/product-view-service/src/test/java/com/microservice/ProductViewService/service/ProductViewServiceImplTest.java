package com.microservice.ProductViewService.service;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.microservice.ProductViewService.dao.ProductViewDAO;
import com.microservice.ProductViewService.exception.ProductViewNotFoundException;
import com.microservice.ProductViewService.model.ProductView;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;

import static org.mockito.Mockito.*;
@RunWith(SpringRunner.class)
public class ProductViewServiceImplTest {
	@TestConfiguration
	static class ProductViewServiceImplTestContextConfiguration
	{
		@Bean
		public ProductViewService productViewService()
		{
			return new ProductViewServiceImpl();
		}
	}
@SpyBean
 private ProductViewService productViewService;

@MockBean
private ProductViewDAO productViewDAO;

@MockBean
private EurekaClient productViewClient;

@MockBean
private RestTemplateBuilder restTemplateBuilder;
@MockBean
private RestTemplate restTemplate;

@Mock
private InstanceInfo instanceInfo;



@Before
public void setup() {
	ProductView pV = new ProductView("gpxl2","Google Pixel 2","Best camera smartphone in the world","50000","37500","3");
	ProductView pV2 = new ProductView("ipx","Google Pixel 2","Best camera smartphone in the world","50000","37500","3");
	List<ProductView> pVS = new ArrayList<ProductView>();
	pVS.add(pV);
	pVS.add(pV2);
	
	//create,display mocks usage
	Mockito.when(productViewDAO.findByProductId(pV.getProductId())).thenReturn(pV);
	Mockito.when(productViewDAO.findAll()).thenReturn(pVS);
	//getService mocks usage
	Mockito.when(productViewClient.getNextServerFromEureka(any(String.class),any(Boolean.class))).thenReturn(instanceInfo);
	Mockito.when(instanceInfo.getHomePageUrl()).thenReturn("baseurl");
	Mockito.when(restTemplate.getForObject(any(String.class), eq(String.class))).thenReturn("{\"data\":\"response\"}");
	
}
	@Test
	public void testCreateProductViewTrue() {
		productViewService.createProductView(anyString());
		Mockito.verify(productViewDAO,Mockito.times(1)).save(any(ProductView.class));
		Mockito.doReturn(true).when(productViewService).createProductView(nullable(String.class));
		assertTrue(productViewService.createProductView(anyString()));
	}
	@Test
	public void testCreateProductViewFalse() {
		productViewService.createProductView(anyString());
		Mockito.verify(productViewDAO,Mockito.times(1)).save(any(ProductView.class));
		Mockito.doReturn(false).when(productViewService).createProductView(nullable(String.class));
		assertFalse(productViewService.createProductView(anyString()));
	}
	@Test
	public void testUpdateProductViewTrue() {
		JsonObject jsonResponse = new JsonParser().parse("{\"name\":\"Pixel2\",\"description\":\"Best smartphone in the world\",\"actualPrice\":\"50000\",\"discountPercentage\":\"25\",\"stock\":\"3\"}").getAsJsonObject();
		Mockito.doReturn(jsonResponse).when(productViewService).getService(nullable(String.class), nullable(RestTemplate.class), nullable(EurekaClient.class), nullable(String.class));
		Mockito.doReturn("37500").when(productViewService).applyPromotion(nullable(String.class), nullable(String.class));
		Mockito.doReturn("Available").when(productViewService).applyStockView(nullable(String.class));
		boolean status = productViewService.updateProductView("gpxl2");
		assertTrue(status);
		Mockito.verify(productViewService,times(4)).getService(nullable(String.class), nullable(RestTemplate.class), nullable(EurekaClient.class), nullable(String.class));
		Mockito.verify(productViewDAO,times(1)).save(any(ProductView.class));
	}
	@Test
	public void testUpdateProductViewFalse() {
		boolean status = productViewService.updateProductView(null);
		assertFalse(status);
		Mockito.verify(productViewService,times(0)).getService(nullable(String.class), nullable(RestTemplate.class), nullable(EurekaClient.class), nullable(String.class));
		Mockito.verify(productViewDAO,times(0)).save(any(ProductView.class));
	}

	@Test
	public void testDeleteProductView() {
		productViewService.deleteProductView(anyString());
		Mockito.verify(productViewDAO,times(1)).deleteByProductId(anyString());
	}

	@Test
	public void testDisplayProductView() {
		ProductView pVfound = productViewService.displayProductView("gpxl2");
		assertEquals("gpxl2",pVfound.getProductId());
	}

	@Test
	public void testDisplayAllProductsView() throws ProductViewNotFoundException {
		List<ProductView>pVSfound = productViewService.displayAllProductsView();
		assertEquals(2,pVSfound.size());
	}

	@Test
	public void testGetService() {
		JsonObject jsonObject = productViewService.getService("anyService", restTemplate, productViewClient, "productId");
		JsonObject jsonResponse = new JsonParser().parse("{\"data\":\"response\"}").getAsJsonObject();
		assertEquals(jsonResponse,jsonObject);
	}

	@Test
	public void testApplyPromotion() {
		String retailPrice = productViewService.applyPromotion("50000", "25");
		assertEquals("37500",retailPrice);
	}

	@Test
	public void testApplyStockView() {
		String stockView1 = productViewService.applyStockView("0");
		String stockView2 = productViewService.applyStockView("2");
		String stockView3 = productViewService.applyStockView("5");
		assertEquals("Out of Stock",stockView1);
		assertEquals("Only 2 left in stock",stockView2);
		assertEquals("5 items available",stockView3);
		
	}

}
