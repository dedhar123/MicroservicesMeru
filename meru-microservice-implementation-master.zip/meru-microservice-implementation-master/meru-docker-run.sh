cd eureka-server
docker build -t eureka-server .
cd ..
cd inventory-service
docker build -t inventory-service .
cd ..
cd price-service
docker build -t price-service .
cd ..
cd product-service
docker build -t product-service .
cd ..
cd product-view-service
docker build -t product-view-service .
cd ..
cd promotion-service
docker build -t promotion-service .
cd ..
cd zuul-api-gateway
docker build -t zuul-api-gateway .
cd ..
docker-compose up
