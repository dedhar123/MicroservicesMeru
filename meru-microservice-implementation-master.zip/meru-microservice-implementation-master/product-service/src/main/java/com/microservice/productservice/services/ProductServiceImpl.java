package com.microservice.productservice.services;


import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.transaction.Transactional;
import java.util.stream.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.microservice.productservice.dao.ProductDao;
import com.microservice.productservice.exception.ProductNotFoundException;
import com.microservice.productservice.model.Product;
import com.microservice.productservice.dao.ProductDao;
import com.microservice.productservice.model.Product;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductDao productDao;
	@Autowired
	private EurekaClient productClient;
	@Autowired
	private RestTemplateBuilder restTemplateBuilder;
	
	static Map<String,Boolean> Status;
	static
	{
	 Status = new HashMap<String,Boolean>();
	 Status.put("product-view-service/productView", false);
	 Status.put("price-service/price", false);
	 Status.put("promotion-service/promotion", false);
	 Status.put("inventory-service/inventory", false);
	}
	
	@Transactional(rollbackOn=Exception.class)
	public void createProduct(Product product) throws Exception
	{
		//status =true;
		RestTemplate restTemplate = restTemplateBuilder.build();
		productDao.save(product);
		try {
		postService("product-view-service/productView",restTemplate,productClient,product.getProductId());
		postService("price-service/price",restTemplate,productClient,product.getProductId());
		postService("promotion-service/promotion",restTemplate,productClient,product.getProductId());
		postService("inventory-service/inventory",restTemplate,productClient,product.getProductId());
		}
		catch(Exception e)
		{
			Status.entrySet().stream().filter(status->status.getValue()==true).forEach(status->{
				try {
					deleteService(status.getKey(),restTemplate,productClient,product.getProductId());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			});
			throw new Exception();
		}
		
	}
	public void updateProduct(String productId, Product product)
	{
		Product productUpdate = productDao.findByProductId(productId);
		productUpdate.setName(product.getName());
		productUpdate.setDescription(product.getDescription());
		productDao.save(productUpdate);
		
	}
	public void postService(String serviceName,RestTemplate restTemplate,EurekaClient productClient,String productId) throws Exception
	{
	
		//Using Zuul Gateway
		InstanceInfo instanceInfo = productClient.getNextServerFromEureka("zuulapigateway", false);
		String baseUrl = instanceInfo.getHomePageUrl();
		baseUrl+="/api/"+serviceName+"/create";
		HttpEntity<Product> request = new HttpEntity<>(new Product(productId));

		ResponseEntity<String> response = restTemplate
		  .exchange(baseUrl, HttpMethod.POST, request, String.class);
		if(response.getStatusCodeValue()==201)
		{
			Status.put(serviceName, true);
		}
		else
		{
			throw new Exception();
		}
	}
	public void deleteService(String serviceName,RestTemplate restTemplate,EurekaClient productViewClient,String productId) throws Exception
	{
	
		//Using Zuul Gateway
		InstanceInfo instanceInfo = productViewClient.getNextServerFromEureka("zuulapigateway", false);
		String baseUrl = instanceInfo.getHomePageUrl();
		baseUrl+="/api/"+serviceName+"/delete/?productId="+productId;
		restTemplate.delete(baseUrl);
	}
	public void deleteProduct(String productId) throws Exception
	{
		RestTemplate restTemplate = restTemplateBuilder.build();
		productDao.deleteByProductId(productId);
		deleteService("product-view-service/productView",restTemplate,productClient,productId);
		deleteService("price-service/price",restTemplate,productClient,productId);
		deleteService("promotion-service/promotion",restTemplate,productClient,productId);
		deleteService("inventory-service/inventory",restTemplate,productClient,productId);
		
	}
	public Product displayProduct(String productId)
	{
		return productDao.findByProductId(productId);
	}
	public List<Product> displayAllProducts() throws ProductNotFoundException
	{
		List<Product> products =(List<Product>) productDao.findAll();
		if(products.isEmpty())
			throw new ProductNotFoundException("There are no products available");
		return products;
	}

}
