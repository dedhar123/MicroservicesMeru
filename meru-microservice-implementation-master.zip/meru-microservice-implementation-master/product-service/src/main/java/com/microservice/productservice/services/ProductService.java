package com.microservice.productservice.services;

import java.util.List;

import com.microservice.productservice.exception.ProductNotFoundException;
import com.microservice.productservice.model.Product;

public interface ProductService {
	public void createProduct(Product product) throws Exception;
	public void updateProduct(String productId, Product product);
	public void deleteProduct(String productId) throws Exception;
	public Product displayProduct(String productId);
	public List<Product> displayAllProducts() throws ProductNotFoundException;
}