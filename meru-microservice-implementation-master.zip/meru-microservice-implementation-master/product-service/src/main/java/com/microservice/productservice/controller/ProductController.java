package com.microservice.productservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.productservice.exception.ProductNotFoundException;
import com.microservice.productservice.model.Product;
import com.microservice.productservice.services.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {
	@Autowired
	private ProductService productService;	
	@RequestMapping(value = "/create",method = RequestMethod.POST)
	public String createProduct(@RequestBody Product product)
	{
		boolean status = true;
		try {
			productService.createProduct(product);
		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		}
		if(status)
			return "Product Created";
		return "Product Creation Unsuccessful";
		
	}
	@RequestMapping(value="/update",method = RequestMethod.PUT)
	public String updateProduct(@RequestParam("productId")String productId, @RequestBody Product product)
	{
		productService.updateProduct(productId, product);
		return "Product Updated";
	}
	@RequestMapping(value="/delete/",method=RequestMethod.DELETE)
	public String deleteProduct(@RequestParam("productId")String productId)
	{
		boolean status = true;
		try
		{
		productService.deleteProduct(productId);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			status = false;
		}
		if(status)
				return "Product Deleted";
		return "Product Deletion Unsuccessful";
	}
	@RequestMapping(value="/")
	public Product displayProduct(@RequestParam("productId") String productId)
	{
		return productService.displayProduct(productId);
	}
	@RequestMapping(value="/all")
	public List<Product> displayAllProducts() throws ProductNotFoundException
	{
		return productService.displayAllProducts();
	}

}
