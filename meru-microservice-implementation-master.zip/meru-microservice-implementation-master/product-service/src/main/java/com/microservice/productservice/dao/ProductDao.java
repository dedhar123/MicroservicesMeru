package com.microservice.productservice.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


import com.microservice.productservice.model.Product;

@Repository
public interface ProductDao extends CrudRepository<Product,String> {
	Product findByProductId(String productId);
	void deleteByProductId(String productId);
}
