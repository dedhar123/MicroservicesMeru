package com.microservice.productservice.model;



import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.Transient;

@Entity
@Table(name = "products")
public class Product implements Serializable{
    /**
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)    
    @Column(nullable = false, unique = true)
    private long id;
    @Column(nullable = false, unique=true)
    private String productId;
    private String name;
    private String description;
   
   public Product()
   {}
   public Product(String productId, String name, String description)
   {
	   this.productId=productId;
	   this.name=name;
	   this.description=description;
   }
   public Product(String productId)
   {
	   this.productId=productId;
   }
	public long getId()
	{
		return id;
	}
	public void setId(long id)
	{
		this.id=id;
	}
	public String getProductId()
	{
		return productId;
	}
	public void setProductId(String productId)
	{
		this.productId=productId;
	}
	public String getName()
	{
		return name;
	}
	public void  setName(String name)
	{
		this.name=name;
	}
	public String getDescription()
	{
		return description;
	}
	public void  setDescription(String description)
	{
		this.description=description;
	}

}
